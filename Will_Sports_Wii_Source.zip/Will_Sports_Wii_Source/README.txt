Will Sports Wii - Bowling Demo Source

This is a starter Wii homebrew source project.
It is NOT a finished boot.dol yet.

Goal:
- Wii Sports-style bowling demo
- D-pad moves aim
- A rolls the ball
- Shake controls can be added later with WPAD acceleration

To make boot.dol:
1. Install devkitPro/devkitPPC + libogc on a PC/cloud builder.
2. Run make in this folder.
3. The output should be boot.dol.

Folder layout after compile:
apps/WillSportsWii/boot.dol
apps/WillSportsWii/meta.xml
apps/WillSportsWii/icon.png
