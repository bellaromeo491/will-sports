#include <gccore.h>
#include <wiiuse/wpad.h>
#include <stdio.h>
#include <stdlib.h>

static void *xfb = NULL;
static GXRModeObj *rmode = NULL;

int main(int argc, char **argv) {
    VIDEO_Init();
    WPAD_Init();

    rmode = VIDEO_GetPreferredMode(NULL);
    xfb = MEM_K0_TO_K1(SYS_AllocateFramebuffer(rmode));
    console_init(xfb, 20, 20, rmode->fbWidth, rmode->xfbHeight, rmode->fbWidth * VI_DISPLAY_PIX_SZ);

    VIDEO_Configure(rmode);
    VIDEO_SetNextFramebuffer(xfb);
    VIDEO_SetBlack(FALSE);
    VIDEO_Flush();
    VIDEO_WaitVSync();
    if (rmode->viTVMode & VI_NON_INTERLACE) VIDEO_WaitVSync();

    int aim = 0;
    int ball = 0;
    int rolling = 0;
    int pins = 10;

    while (1) {
        WPAD_ScanPads();
        u32 pressed = WPAD_ButtonsDown(0);
        u32 held = WPAD_ButtonsHeld(0);

        if (pressed & WPAD_BUTTON_HOME) exit(0);
        if (held & WPAD_BUTTON_LEFT) aim--;
        if (held & WPAD_BUTTON_RIGHT) aim++;
        if (aim < -10) aim = -10;
        if (aim > 10) aim = 10;

        if ((pressed & WPAD_BUTTON_A) && !rolling) {
            rolling = 1;
            ball = 0;
        }

        if (rolling) {
            ball++;
            if (ball > 30) {
                rolling = 0;
                pins = 10 - abs(aim);
                if (pins < 0) pins = 0;
            }
        }

        printf("\x1b[2J");
        printf("Will Sports Wii - Bowling Demo\n");
        printf("--------------------------------\n\n");
        printf("D-Pad Left/Right = Aim\n");
        printf("A = Roll ball\n");
        printf("HOME = Exit\n\n");
        printf("Aim: %d\n", aim);
        printf("Ball: %s %d\n", rolling ? "Rolling" : "Ready", ball);
        printf("Pins left after last roll: %d\n\n", pins);
        printf("Lane:\n");
        printf("          ||||||||||\n");
        printf("          ||||||||||\n");
        printf("          ||||||||||\n");
        printf("             O\n\n");
        printf("v0.1 source by Bellaromeo project\n");

        VIDEO_WaitVSync();
    }

    return 0;
}
